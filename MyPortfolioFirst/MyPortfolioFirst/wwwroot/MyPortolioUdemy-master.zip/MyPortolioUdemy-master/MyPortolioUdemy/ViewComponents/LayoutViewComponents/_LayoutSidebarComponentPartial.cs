﻿using Microsoft.AspNetCore.Mvc;

namespace MyPortolioUdemy.ViewComponents.LayoutViewComponents
{
	public class _LayoutSidebarComponentPartial:ViewComponent
	{
		public IViewComponentResult Invoke()
		{
			return View();
		}
	}
}
